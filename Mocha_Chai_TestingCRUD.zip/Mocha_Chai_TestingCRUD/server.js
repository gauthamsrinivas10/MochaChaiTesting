const express = require("express");
const app = express();
const fs = require("fs");
const { MovieModel } = require("./schema/Movie");
require("./db")
app.use(express.json());
app.post("/addMovies", async (req,res)=>{
    try{
        const {body} = req;
        const {name,language,rate,type,imageUrl} = body
        if( name && language && rate && type && imageUrl && name !== "" && language !== "" && rate !== "" && type !== "" && imageUrl !== ""){
            const newMovie = new MovieModel({name,language,rate,type,imageUrl})
            const doc = await newMovie.save();
        res.json({message: "new entry added", name, language,rate,type,imageUrl })
        
        }
        else{
            res.status(401).json({message: "invalid input"})
        }
    
        
    }
    catch(error){
        res.status(500).json({message: "internal server error"})
        console.log(error)
    }
  
})

app.get( "/", (req , res )=> {
    fs.readFile("./db.json", "utf-8" , (err,content)=>{
        res.json(JSON.parse(content));
       
    })
    
})


app.put("/update" , (req,res)=>{
    const del = MovieModel.updateOne({name: "Black Panther"}, {$set:{language:"SPANISH"}}, {new: true},function (err, done) {
        if (err){
            console.log(err)
        }
        else{
            //console.log("Result : ", doc);
            console.log(done)
            res.json( done.name)
        }
    })
    })
app.delete("/delete" , (req,res)=>{
const del = MovieModel.findOneAndDelete({"name": {$eq:"Aladdin 40 Thieves"}},function (err, done) {
    if (err){
        console.log(err)
    }
    else{
        //console.log("Result : ", doc);
        console.log(done)
        res.json( done.name)
    }
})
})

app.get( "/movies", (req , res )=> {
   

        const done = MovieModel.findOne({"name": {$eq:"Black Panther"} }, function (err, done) {
            if (err){
                console.log(err)
            }
            else{
                //console.log("Result : ", doc);
                console.log(done)
                res.json( done.name)
            }
        })
   
    
})
app.listen(6500);

module.exports = app;
