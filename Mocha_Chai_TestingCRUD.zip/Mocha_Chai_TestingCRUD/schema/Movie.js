const { Schema, model} = require("mongoose");

const MovieSchema = new Schema({
    name : {type: String, required: true},
    language: {type:String , required:true},
    rate: {type: String, required: true},
    type: {type: String, required: true}, 
    imageUrl : {type: String, required: true}
})

const MovieModel = model("Movie",MovieSchema , "Movies" );
module.exports = {MovieSchema, MovieModel}