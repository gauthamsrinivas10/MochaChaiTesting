let chai = require('chai');
let chaiHttp  = require('chai-http');
let expect = chai.expect;
chai.use(chaiHttp);
const app = require("../server");
let should = chai.should();
let server = require('../server');
let mongoose = require("mongoose");

describe('Testing  my Rest Api', () => {
    it('should  return status 200 for /', ()=>{
        chai
            .request(app)
            .get('/')
            .then(function(res){
                expect(res).to.have.status(200);
                
            })
            .catch(function(err){
                throw(err)
            })
    });

    it('should  return status 200 for /movies', ()=>{
        chai
            .request(app)
            .get('/movies')
            .then(function(res){ 
                expect(res).to.have.status(200);              
                
                expect(res.body).to.eq("Black Panther");
            })
            .catch(function(err){
                throw(err)
            })
    })

    it('should  return exact value for /movies', ()=>{
        chai
            .request(app)
            .get('/movies')
            .then(function(res){                           
                
                expect(res.body).to.eq("Black Panther");
            })
            .catch(function(err){
                throw(err)
            })
    })

    it('/addMovies', ()=>{
        let movie = {
            name:"Aladdin 40 Thieves",
            language:"ENGLISH",
            rate:4.5,
            type:"Action Adventure Fantasy",
            imageUrl:"https://image.ibb.co/f0hhZd/cp.jpg"
        }
        chai
            .request(app)
            .post("/addMovies")
            .send(movie)
            .then(function (res) {
                            expect(res).to.have.status(200);
            
                        })
                        .catch(function (err) {
                            throw (err);
                        });                
           
    })

    it('/update', ()=>{
        let movie = {
            name:"Black Panther"            
        }
        chai
            .request(app)
            .put("/update")
            .send(movie)
            .then(function (res) {
                            expect(res).to.have.status(200);
            
                        })
                        .catch(function (err) {
                            throw (err);
                        });                
           
    })

    it('/delete', ()=>{
        let movie = {
            name:"Aladdin 40 Thieves"            
        }
        chai
            .request(app)
            .delete("/delete")
            .send(movie)
            .then(function (res) {
                            expect(res).to.have.status(200);
            
                        })
                        .catch(function (err) {
                            throw (err);
                        });                
           
    })
    it('should  return status negative test  for /movies', ()=>{
        chai
            .request(app)
            .get('/movies')
            .then(function(res){ 
                              
                expect(res.body).to.eq("Bla Panther");
                
            })
            .catch(function(err){
                throw(err)
            })
    })
    it('should return the status 404', () => {
        chai
            .request(app)
            .get('/movie')
            .then(function (res) {
                expect(res).to.have.status(404);

            })
            .catch(function (err) {
                throw (err);
            });
    });
})